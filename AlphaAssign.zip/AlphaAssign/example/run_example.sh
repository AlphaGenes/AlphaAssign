
AlphaAssign -genotypes data/trueGenotypes.txt \
                        -out outputs/assign \
                        -potentialsires data/sire.list
